namespace InterfaceSegregation
{
    public interface ITestActivities
    {
        void Test();
    }
}