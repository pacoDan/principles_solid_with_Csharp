namespace InterfaceSegregation
{
    public interface IDevelopActivities
    {
        void Develop();
    }
}