namespace InterfaceSegregation
{
    public interface IWorkTeamActivities
    {
        void Plan();
        void Comunicate();
    }
}