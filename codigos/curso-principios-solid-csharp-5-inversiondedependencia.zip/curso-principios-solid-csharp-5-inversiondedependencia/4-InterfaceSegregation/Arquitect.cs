
namespace InterfaceSegregation
{
    public class Arquitect : IActivities
    {
        public void Comunicate()
        {
            throw new NotImplementedException();
        }

        public void Design()
        {
            throw new NotImplementedException();
        }

        public void Develop()
        {
            throw new NotImplementedException();
        }

        public void Plan()
        {
            throw new NotImplementedException();
        }

        public void Test()
        {
            throw new NotImplementedException();
        }
    }
}