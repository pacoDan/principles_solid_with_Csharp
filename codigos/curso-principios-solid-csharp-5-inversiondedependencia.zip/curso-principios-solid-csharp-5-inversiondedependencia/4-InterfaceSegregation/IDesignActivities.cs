namespace InterfaceSegregation
{
    public interface IDesignActivities
    {
        void Design();
    }
}